package com.example.network

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
