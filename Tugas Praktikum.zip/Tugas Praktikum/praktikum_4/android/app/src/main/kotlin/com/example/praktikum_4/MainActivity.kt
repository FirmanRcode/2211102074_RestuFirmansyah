package com.example.praktikum_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
