<?php
echo '<form method="GET" action="proses.php">';
echo 'Nama: <input type="text" name="nama">';
echo '<input type="submit">';
echo '</form>';
echo '<br>';
?>

<?php
echo '<form method="POST" action="proses2.php">';
echo 'Nama: <input type="text" name="nama">';
echo '<input type="submit">';
echo '</form>';
echo '<br>';
?>