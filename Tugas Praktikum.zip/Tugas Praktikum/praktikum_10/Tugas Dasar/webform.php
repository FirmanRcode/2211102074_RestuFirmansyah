<form method="POST" action="proses.php"> 
  Umur : <input type="int" name="age" required> <br>  
  <input type="submit" value="Input"> 
</form>
<?php

?>