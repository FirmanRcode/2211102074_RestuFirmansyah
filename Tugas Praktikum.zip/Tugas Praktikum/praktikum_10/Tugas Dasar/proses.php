<?php
if ($_POST['age'] <= 18) {
  echo "Kurang gede dek";
  echo "<br>";
} else {
  echo "Dewasa";
}
?>