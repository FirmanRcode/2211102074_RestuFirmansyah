package com.example.praktikum_5

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
