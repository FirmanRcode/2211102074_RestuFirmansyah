package com.example.modul_9

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
