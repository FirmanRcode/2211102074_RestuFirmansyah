package com.example.modul_12

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
