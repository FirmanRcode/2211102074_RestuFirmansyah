package com.example.praktikum_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
