void main() {
  var nilai = 100;
  if (nilai == 100) {
    print('Selamat, Anda Terbaik!');
  } else if (nilai >= 80) {
    print('Anda Lulus!');
  } else {
    print('Maaf, Anda Tidak Lulus!');
  }
}
