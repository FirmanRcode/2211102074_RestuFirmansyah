void main() {
  int myInt = 22;
  double myDouble = 20.8;
  String myString = "Hello, Restu";
  bool myBool = false;
  List<String> myList = ['Semarang', 'Banyumas', 'Jakarta'];
  Map<String, int> myMap = {'apple': 1, 'banana': 2};

  // Print variable sesuai yang di deklarasikan
  print(myInt);
  print(myDouble);
  print(myString);
  print(myBool);
  print(myList);
  print(myMap);
}
