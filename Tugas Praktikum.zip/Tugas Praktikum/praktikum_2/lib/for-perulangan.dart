void main() {
  for (int i = 21102200; i <= 21102210; i++) {
    print('Mahasiswa ke-$i');
  }
  var mahasiswa = ['Ananda', 'Surya', 'Kusuma', 'Wahyu', 'Pram'];
  mahasiswa.forEach((nama) {
    print('Nama Mahasiswa: $nama');
  });
}
